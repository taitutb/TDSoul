window.__require = function t(e, n, i) {
function s(o, r) {
if (!n[o]) {
if (!e[o]) {
var c = o.split("/");
c = c[c.length - 1];
if (!e[c]) {
var u = "function" == typeof __require && __require;
if (!r && u) return u(c, !0);
if (a) return a(c, !0);
throw new Error("Cannot find module '" + o + "'");
}
o = c;
}
var l = n[o] = {
exports: {}
};
e[o][0].call(l.exports, function(t) {
return s(e[o][1][t] || t);
}, l, l.exports, t, e, n, i);
}
return n[o].exports;
}
for (var a = "function" == typeof __require && __require, o = 0; o < i.length; o++) s(i[o]);
return s;
}({
ActorRenderer: [ function(t, e) {
"use strict";
cc._RF.push(e, "1a792KO87NBg7vCCIp1jq+j", "ActorRenderer");
var n = t("Game"), i = t("Types"), s = t("Utils"), a = i.ActorPlayingState;
cc.Class({
extends: cc.Component,
properties: {
playerInfo: {
default: null,
type: cc.Node
},
stakeOnTable: {
default: null,
type: cc.Node
},
cardInfo: {
default: null,
type: cc.Node
},
cardPrefab: {
default: null,
type: cc.Prefab
},
anchorCards: {
default: null,
type: cc.Node
},
spPlayerName: {
default: null,
type: cc.Sprite
},
labelPlayerName: {
default: null,
type: cc.Label
},
labelTotalStake: {
default: null,
type: cc.Label
},
spPlayerPhoto: {
default: null,
type: cc.Sprite
},
spCountdown: {
default: null,
type: cc.Sprite
},
labelStakeOnTable: {
default: null,
type: cc.Label
},
spChips: {
default: [],
type: cc.Sprite
},
labelCardInfo: {
default: null,
type: cc.Label
},
spCardInfo: {
default: null,
type: cc.Sprite
},
animFX: {
default: null,
type: cc.Node
},
cardSpace: 0
},
onLoad: function() {},
init: function(t, e, i, s, a) {
this.actor = this.getComponent("Actor");
this.sgCountdown = null;
this.turnDuration = s;
this.playerInfo.position = e;
this.stakeOnTable.position = i;
this.labelPlayerName.string = t.name;
this.updateTotalStake(t.gold);
var o = t.photoIdx % 5;
this.spPlayerPhoto.spriteFrame = n.instance.assetMng.playerPhotos[o];
this.animFX = this.animFX.getComponent("FXPlayer");
this.animFX.init();
this.animFX.show(!1);
this.cardInfo.active = !1;
this.progressTimer = this.initCountdown();
if (a) {
this.spCardInfo.getComponent("SideSwitcher").switchSide();
this.spPlayerName.getComponent("SideSwitcher").switchSide();
}
},
initDealer: function() {
this.actor = this.getComponent("Actor");
this.animFX = this.animFX.getComponent("FXPlayer");
this.animFX.init();
this.animFX.show(!1);
},
updateTotalStake: function(t) {
this.labelTotalStake.string = "$" + t;
},
initCountdown: function() {
var t = n.instance.assetMng.texCountdown.getTexture();
this.sgCountdown = new _ccsg.Sprite(t);
var e = new cc.ProgressTimer(this.sgCountdown);
e.setName("progressTimer");
e.setMidpoint(cc.v2(.5, .5));
e.setType(cc.ProgressTimer.Type.RADIAL);
this.playerInfo._sgNode.addChild(e);
e.setPosition(cc.v2(0, 0));
e.setPercentage(0);
return e;
},
startCountdown: function() {
if (this.progressTimer) {
var t = cc.progressFromTo(this.turnDuration, 0, 100);
this.progressTimer.runAction(t);
}
},
resetCountdown: function() {
if (this.progressTimer) {
this.progressTimer.stopAllActions();
this.progressTimer.setPercentage(0);
}
},
playBlackJackFX: function() {
this.animFX.playFX("blackjack");
},
playBustFX: function() {
this.animFX.playFX("bust");
},
onDeal: function(t, e) {
var n = cc.instantiate(this.cardPrefab).getComponent("Card");
this.anchorCards.addChild(n.node);
n.init(t);
n.reveal(e);
var i = cc.v2(0, 0), s = this.actor.cards.length - 1, a = cc.v2(this.cardSpace * s, 0);
n.node.setPosition(i);
var o = cc.moveTo(.5, a), r = cc.callFunc(this._onDealEnd, this, this.cardSpace * s);
n.node.runAction(cc.sequence(o, r));
},
_onDealEnd: function(t, e) {
this.resetCountdown();
this.actor.state === a.Normal && this.startCountdown();
this.updatePoint();
this._updatePointPos(e);
},
onReset: function() {
this.cardInfo.active = !1;
this.anchorCards.removeAllChildren();
this._resetChips();
},
onRevealHoldCard: function() {
cc.find("cardPrefab", this.anchorCards).getComponent("Card").reveal(!0);
this.updateState();
},
updatePoint: function() {
this.cardInfo.active = !0;
this.labelCardInfo.string = this.actor.bestPoint;
switch (this.actor.hand) {
case i.Hand.BlackJack:
this.animFX.show(!0);
this.animFX.playFX("blackjack");
break;

case i.Hand.FiveCard:
}
},
_updatePointPos: function(t) {
this.cardInfo.x = t + 50;
},
showStakeChips: function(t) {
var e = this.spChips, n = 0;
t > 5e4 ? n = 5 : t > 25e3 ? n = 4 : t > 1e4 ? n = 3 : t > 5e3 ? n = 2 : t > 0 && (n = 1);
for (var i = 0; i < n; ++i) e[i].enabled = !0;
},
_resetChips: function() {
for (var t = 0; t < this.spChips.length; ++t) this.spChips.enabled = !1;
},
updateState: function() {
switch (this.actor.state) {
case a.Normal:
this.cardInfo.active = !0;
this.spCardInfo.spriteFrame = n.instance.assetMng.texCardInfo;
this.updatePoint();
break;

case a.Bust:
var t = s.getMinMaxPoint(this.actor.cards).min;
this.labelCardInfo.string = "爆牌(" + t + ")";
this.spCardInfo.spriteFrame = n.instance.assetMng.texBust;
this.cardInfo.active = !0;
this.animFX.show(!0);
this.animFX.playFX("bust");
this.resetCountdown();
break;

case a.Stand:
var e = s.getMinMaxPoint(this.actor.cards).max;
this.labelCardInfo.string = "停牌(" + e + ")";
this.spCardInfo.spriteFrame = n.instance.assetMng.texCardInfo;
this.resetCountdown();
}
}
});
cc._RF.pop();
}, {
Game: "Game",
Types: "Types",
Utils: "Utils"
} ],
Actor: [ function(t, e) {
"use strict";
cc._RF.push(e, "7d008dTf6xB2Z0wCAdzh1Rx", "Actor");
var n = t("Types"), i = t("Utils"), s = n.ActorPlayingState;
cc.Class({
extends: cc.Component,
properties: {
cards: {
default: [],
serializable: !1,
visible: !1
},
holeCard: {
default: null,
serializable: !1,
visible: !1
},
bestPoint: {
get: function() {
return i.getMinMaxPoint(this.cards).max;
}
},
hand: {
get: function() {
var t = this.cards.length;
this.holeCard && ++t;
return t >= 5 ? n.Hand.FiveCard : 2 === t && 21 === this.bestPoint ? n.Hand.BlackJack : n.Hand.Normal;
}
},
canReport: {
get: function() {
return this.hand !== n.Hand.Normal;
},
visible: !1
},
renderer: {
default: null,
type: cc.Node
},
state: {
default: s.Normal,
notify: function(t) {
this.state !== t && this.renderer.updateState();
},
type: s,
serializable: !1
}
},
init: function() {
this.ready = !0;
this.renderer = this.getComponent("ActorRenderer");
},
addCard: function(t) {
this.cards.push(t);
this.renderer.onDeal(t, !0);
var e = this.holeCard ? [ this.holeCard ].concat(this.cards) : this.cards;
i.isBust(e) && (this.state = s.Bust);
},
addHoleCard: function(t) {
this.holeCard = t;
this.renderer.onDeal(t, !1);
},
stand: function() {
this.state = s.Stand;
},
revealHoldCard: function() {
if (this.holeCard) {
this.cards.unshift(this.holeCard);
this.holeCard = null;
this.renderer.onRevealHoldCard();
}
},
report: function() {
this.state = s.Report;
},
reset: function() {
this.cards = [];
this.holeCard = null;
this.reported = !1;
this.state = s.Normal;
this.renderer.onReset();
}
});
cc._RF.pop();
}, {
Types: "Types",
Utils: "Utils"
} ],
AssetMng: [ function(t, e) {
"use strict";
cc._RF.push(e, "54522LcoVpPHbrqYgwp/1Qm", "AssetMng");
cc.Class({
extends: cc.Component,
properties: {
texBust: {
default: null,
type: cc.SpriteFrame
},
texCardInfo: {
default: null,
type: cc.SpriteFrame
},
texCountdown: {
default: null,
type: cc.SpriteFrame
},
texBetCountdown: {
default: null,
type: cc.SpriteFrame
},
playerPhotos: {
default: [],
type: cc.SpriteFrame
}
}
});
cc._RF.pop();
}, {} ],
AudioMng: [ function(t, e) {
"use strict";
cc._RF.push(e, "01ca4tStvVH+JmZ5TNcmuAu", "AudioMng");
cc.Class({
extends: cc.Component,
properties: {
winAudio: {
default: null,
type: cc.AudioClip
},
loseAudio: {
default: null,
type: cc.AudioClip
},
cardAudio: {
default: null,
type: cc.AudioClip
},
buttonAudio: {
default: null,
type: cc.AudioClip
},
chipsAudio: {
default: null,
type: cc.AudioClip
},
bgm: {
default: null,
type: cc.AudioClip
}
},
playMusic: function() {
cc.audioEngine.playMusic(this.bgm, !0);
},
pauseMusic: function() {
cc.audioEngine.pauseMusic();
},
resumeMusic: function() {
cc.audioEngine.resumeMusic();
},
_playSFX: function(t) {
cc.audioEngine.playEffect(t, !1);
},
playWin: function() {
this._playSFX(this.winAudio);
},
playLose: function() {
this._playSFX(this.loseAudio);
},
playCard: function() {
this._playSFX(this.cardAudio);
},
playChips: function() {
this._playSFX(this.chipsAudio);
},
playButton: function() {
this._playSFX(this.buttonAudio);
}
});
cc._RF.pop();
}, {} ],
Bet: [ function(t, e) {
"use strict";
cc._RF.push(e, "28f38yToT1Pw7NgyeCvRxDC", "Bet");
var n = t("Game");
cc.Class({
extends: cc.Component,
properties: {
chipPrefab: {
default: null,
type: cc.Prefab
},
btnChips: {
default: [],
type: cc.Node
},
chipValues: {
default: [],
type: "Integer"
},
anchorChipToss: {
default: null,
type: cc.Node
}
},
init: function() {
this._registerBtns();
},
_registerBtns: function() {
for (var t = this, e = function(e) {
t.btnChips[i].on("touchstart", function() {
n.instance.addStake(t.chipValues[e]) && t.playAddChip();
}, this);
}, i = 0; i < t.btnChips.length; ++i) e(i);
},
playAddChip: function() {
var t = cc.v2(100 * (Math.random() - .5), 100 * (Math.random() - .5)), e = cc.instantiate(this.chipPrefab);
this.anchorChipToss.addChild(e);
e.setPosition(t);
e.getComponent("TossChip").play();
},
resetChips: function() {
n.instance.resetStake();
n.instance.info.enabled = !1;
this.resetTossedChips();
},
resetTossedChips: function() {
this.anchorChipToss.removeAllChildren();
}
});
cc._RF.pop();
}, {
Game: "Game"
} ],
ButtonScaler: [ function(t, e) {
"use strict";
cc._RF.push(e, "a171dSnCXFMRIqs1IWdvgWM", "ButtonScaler");
cc.Class({
extends: cc.Component,
properties: {
pressedScale: 1,
transDuration: 0
},
onLoad: function() {
var t = this, e = cc.find("Menu/AudioMng") || cc.find("Game/AudioMng");
e && (e = e.getComponent("AudioMng"));
t.initScale = this.node.scale;
t.button = t.getComponent(cc.Button);
t.scaleDownAction = cc.scaleTo(t.transDuration, t.pressedScale);
t.scaleUpAction = cc.scaleTo(t.transDuration, t.initScale);
function n() {
this.stopAllActions();
this.runAction(t.scaleUpAction);
}
this.node.on("touchstart", function() {
this.stopAllActions();
e && e.playButton();
this.runAction(t.scaleDownAction);
}, this.node);
this.node.on("touchend", n, this.node);
this.node.on("touchcancel", n, this.node);
}
});
cc._RF.pop();
}, {} ],
Card: [ function(t, e) {
"use strict";
cc._RF.push(e, "ab67e5QkiVCBZ3DIMlWhiAt", "Card");
cc.Class({
extends: cc.Component,
properties: {
point: {
default: null,
type: cc.Label
},
suit: {
default: null,
type: cc.Sprite
},
mainPic: {
default: null,
type: cc.Sprite
},
cardBG: {
default: null,
type: cc.Sprite
},
redTextColor: cc.Color.WHITE,
blackTextColor: cc.Color.WHITE,
texFrontBG: {
default: null,
type: cc.SpriteFrame
},
texBackBG: {
default: null,
type: cc.SpriteFrame
},
texFaces: {
default: [],
type: cc.SpriteFrame
},
texSuitBig: {
default: [],
type: cc.SpriteFrame
},
texSuitSmall: {
default: [],
type: cc.SpriteFrame
}
},
init: function(t) {
var e = t.point > 10;
this.mainPic.spriteFrame = e ? this.texFaces[t.point - 10 - 1] : this.texSuitBig[t.suit - 1];
this.point.string = t.pointName;
t.isRedSuit ? this.point.node.color = this.redTextColor : this.point.node.color = this.blackTextColor;
this.suit.spriteFrame = this.texSuitSmall[t.suit - 1];
},
reveal: function(t) {
this.point.node.active = t;
this.suit.node.active = t;
this.mainPic.node.active = t;
this.cardBG.spriteFrame = t ? this.texFrontBG : this.texBackBG;
}
});
cc._RF.pop();
}, {} ],
CounterTest: [ function(t, e) {
"use strict";
cc._RF.push(e, "b0926/aIatATYgTuL0RyW/q", "CounterTest");
cc.Class({
extends: cc.Component,
properties: {
target: {
default: null,
type: cc.Label
}
},
onLoad: function() {
this.target.node.color = cc.Color.GREEN;
},
update: function() {}
});
cc._RF.pop();
}, {} ],
Dealer: [ function(t, e) {
"use strict";
cc._RF.push(e, "ce2dfoqEulHCLjS1Z9xPN7t", "Dealer");
var n = t("Actor"), i = t("Utils");
cc.Class({
extends: n,
properties: {
bestPoint: {
get: function() {
var t = this.holeCard ? [ this.holeCard ].concat(this.cards) : this.cards;
return i.getMinMaxPoint(t).max;
},
override: !0
}
},
init: function() {
this._super();
this.renderer.initDealer();
},
wantHit: function() {
var e = t("Game"), n = t("Types"), i = this.bestPoint;
if (21 === i) return !1;
if (i <= 11) return !0;
var s = e.instance.player;
switch (e.instance._getPlayerResult(s, this)) {
case n.Outcome.Win:
return !0;

case n.Outcome.Lose:
return !1;
}
return this.bestPoint < 17;
}
});
cc._RF.pop();
}, {
Actor: "Actor",
Game: "Game",
Types: "Types",
Utils: "Utils"
} ],
Decks: [ function(t, e) {
"use strict";
cc._RF.push(e, "17024G0JFpHcLI5GREbF8VN", "Decks");
var n = t("Types");
function i(t) {
this._numberOfDecks = t;
this._cardIds = new Array(52 * t);
this.reset();
}
i.prototype.reset = function() {
this._cardIds.length = 52 * this._numberOfDecks;
for (var t = 0, e = n.Card.fromId, i = 0; i < this._numberOfDecks; ++i) for (var s = 0; s < 52; ++s) {
this._cardIds[t] = e(s);
++t;
}
};
i.prototype.draw = function() {
var t = this._cardIds, e = t.length;
if (0 === e) return null;
var n = Math.random() * e | 0, i = t[n], s = t[e - 1];
t[n] = s;
t.length = e - 1;
return i;
};
e.exports = i;
cc._RF.pop();
}, {
Types: "Types"
} ],
FXPlayer: [ function(t, e) {
"use strict";
cc._RF.push(e, "68da2yjdGVMSYhXLN9DukIB", "FXPlayer");
cc.Class({
extends: cc.Component,
init: function() {
this.anim = this.getComponent(cc.Animation);
this.sprite = this.getComponent(cc.Sprite);
},
show: function(t) {
this.sprite.enabled = t;
},
playFX: function(t) {
this.anim.play(t);
},
hideFX: function() {
this.sprite.enabled = !1;
}
});
cc._RF.pop();
}, {} ],
Game: [ function(t, e) {
"use strict";
cc._RF.push(e, "63738OONCFKHqsf4QSeJSun", "Game");
var n = t("PlayerData").players, i = t("Decks"), s = t("Types"), a = s.ActorPlayingState, o = t("game-fsm"), r = cc.Class({
extends: cc.Component,
properties: {
playerAnchors: {
default: [],
type: cc.Node
},
playerPrefab: {
default: null,
type: cc.Prefab
},
dealer: {
default: null,
type: cc.Node
},
inGameUI: {
default: null,
type: cc.Node
},
betUI: {
default: null,
type: cc.Node
},
assetMng: {
default: null,
type: cc.Node
},
audioMng: {
default: null,
type: cc.Node
},
turnDuration: 0,
betDuration: 0,
totalChipsNum: 0,
totalDiamondNum: 0,
numberOfDecks: {
default: 1,
type: "Integer"
}
},
statics: {
instance: null
},
onLoad: function() {
r.instance = this;
this.inGameUI = this.inGameUI.getComponent("InGameUI");
this.assetMng = this.assetMng.getComponent("AssetMng");
this.audioMng = this.audioMng.getComponent("AudioMng");
this.betUI = this.betUI.getComponent("Bet");
this.inGameUI.init(this.betDuration);
this.betUI.init();
this.dealer = this.dealer.getComponent("Dealer");
this.dealer.init();
this.player = null;
this.createPlayers();
this.info = this.inGameUI.resultTxt;
this.totalChips = this.inGameUI.labelTotalChips;
this.decks = new i(this.numberOfDecks);
this.fsm = o;
this.fsm.init(this);
this.updateTotalChips();
this.audioMng.playMusic();
},
addStake: function(t) {
if (this.totalChipsNum < t) {
console.log("not enough chips!");
this.info.enabled = !0;
this.info.string = "金币不足!";
return !1;
}
this.totalChipsNum -= t;
this.updateTotalChips();
this.player.addStake(t);
this.audioMng.playChips();
this.info.enabled = !1;
this.info.string = "请下注";
return !0;
},
resetStake: function() {
this.totalChipsNum += this.player.stakeNum;
this.player.resetStake();
this.updateTotalChips();
},
updateTotalChips: function() {
this.totalChips.string = this.totalChipsNum;
this.player.renderer.updateTotalStake(this.totalChipsNum);
},
createPlayers: function() {
for (var t = 0; t < 5; ++t) {
var e = cc.instantiate(this.playerPrefab), i = this.playerAnchors[t], s = t > 2;
i.addChild(e);
e.position = cc.v2(0, 0);
var a = cc.find("anchorPlayerInfo", i).getPosition(), o = cc.find("anchorStake", i).getPosition();
e.getComponent("ActorRenderer").init(n[t], a, o, this.turnDuration, s);
if (2 === t) {
this.player = e.getComponent("Player");
this.player.init();
}
}
},
hit: function() {
this.player.addCard(this.decks.draw());
this.player.state === a.Bust && this.fsm.onPlayerActed();
this.audioMng.playCard();
this.audioMng.playButton();
},
stand: function() {
this.player.stand();
this.audioMng.playButton();
this.fsm.onPlayerActed();
},
deal: function() {
this.fsm.toDeal();
this.audioMng.playButton();
},
start: function() {
this.fsm.toBet();
this.audioMng.playButton();
},
report: function() {
this.player.report();
this.fsm.onPlayerActed();
},
quitToMenu: function() {
cc.director.loadScene("menu");
},
onEnterDealState: function() {
this.betUI.resetTossedChips();
this.inGameUI.resetCountdown();
this.player.renderer.showStakeChips(this.player.stakeNum);
this.player.addCard(this.decks.draw());
var t = this.decks.draw();
this.dealer.addHoleCard(t);
this.player.addCard(this.decks.draw());
this.dealer.addCard(this.decks.draw());
this.audioMng.playCard();
this.fsm.onDealed();
},
onPlayersTurnState: function(t) {
t && this.inGameUI.showGameState();
},
onEnterDealersTurnState: function() {
for (;this.dealer.state === a.Normal; ) this.dealer.wantHit() ? this.dealer.addCard(this.decks.draw()) : this.dealer.stand();
this.fsm.onDealerActed();
},
onEndState: function(t) {
if (t) {
this.dealer.revealHoldCard();
this.inGameUI.showResultState();
switch (this._getPlayerResult(this.player, this.dealer)) {
case s.Outcome.Win:
this.info.string = "You Win";
this.audioMng.pauseMusic();
this.audioMng.playWin();
this.totalChipsNum += this.player.stakeNum;
var e = this.player.stakeNum;
!this.player.state === s.ActorPlayingState.Report && (this.player.hand === s.Hand.BlackJack ? e *= 1.5 : e *= 2);
this.totalChipsNum += e;
this.updateTotalChips();
break;

case s.Outcome.Lose:
this.info.string = "You Lose";
this.audioMng.pauseMusic();
this.audioMng.playLose();
break;

case s.Outcome.Tie:
this.info.string = "Draw";
this.totalChipsNum += this.player.stakeNum;
this.updateTotalChips();
}
}
this.info.enabled = t;
},
onBetState: function(t) {
if (t) {
this.decks.reset();
this.player.reset();
this.dealer.reset();
this.info.string = "请下注";
this.inGameUI.showBetState();
this.inGameUI.startCountdown();
this.audioMng.resumeMusic();
}
this.info.enabled = t;
},
_getPlayerResult: function(t, e) {
var n = s.Outcome;
return t.state === a.Bust ? n.Lose : e.state === a.Bust ? n.Win : t.state === a.Report ? n.Win : t.hand > e.hand ? n.Win : t.hand < e.hand ? n.Lose : t.bestPoint === e.bestPoint ? n.Tie : t.bestPoint < e.bestPoint ? n.Lose : n.Win;
}
});
cc._RF.pop();
}, {
Decks: "Decks",
PlayerData: "PlayerData",
Types: "Types",
"game-fsm": "game-fsm"
} ],
HotUpdate: [ function(t, e) {
"use strict";
cc._RF.push(e, "e390cpl5vpL54CRkH0xI8Ul", "HotUpdate");
var n = t("../UI/UpdatePanel");
cc.Class({
extends: cc.Component,
properties: {
panel: n,
manifestUrl: {
type: cc.Asset,
default: null
},
updateUI: cc.Node,
_updating: !1,
_canRetry: !1,
_storagePath: "",
stringHost: "https://bum.vin/remote-assets/",
isAutoHotUpdate: !0
},
start: function() {
if (this.isAutoHotUpdate) {
var t = this;
this.loadCustomManifest();
setTimeout(function() {
t.checkUpdate();
}, 1e3);
setTimeout(function() {
t.hotUpdate();
}, 5e3);
}
},
checkCb: function(t) {
cc.log("Code: " + t.getEventCode());
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.panel.info.string = "No local manifest file found, hot update skipped.";
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.panel.info.string = "Fail to download manifest file, hot update skipped.";
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.panel.info.string = "Already up to date with the latest remote version.";
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.panel.info.string = "New version found, please try to update. (" + this._am.getTotalBytes() + ")";
this.panel.checkBtn.active = !1;
this.panel.fileProgress.progress = 0;
this.panel.byteProgress.progress = 0;
break;

default:
return;
}
this._am.setEventCallback(null);
this._checkListener = null;
this._updating = !1;
},
updateCb: function(t) {
var e = !1, n = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.panel.info.string = "No local manifest file found, hot update skipped.";
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
this.panel.byteProgress.progress = t.getPercent();
this.panel.fileProgress.progress = t.getPercentByFile();
this.panel.fileLabel.string = t.getDownloadedFiles() + " / " + t.getTotalFiles();
this.panel.byteLabel.string = t.getDownloadedBytes() + " / " + t.getTotalBytes();
var i = t.getMessage();
i && (this.panel.info.string = "Updated file: " + i);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.panel.info.string = "Fail to download manifest file, hot update skipped.";
n = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.panel.info.string = "Already up to date with the latest remote version.";
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
this.panel.info.string = "Update finished. " + t.getMessage();
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this.panel.info.string = "Update failed. " + t.getMessage();
this.panel.retryBtn.active = !0;
this._updating = !1;
this._canRetry = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
this.panel.info.string = "Asset update error: " + t.getAssetId() + ", " + t.getMessage();
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
this.panel.info.string = t.getMessage();
}
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
}
console.log("need restart: " + e);
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var s = jsb.fileUtils.getSearchPaths();
console.log("search path: " + JSON.stringify(s));
var a = this._am.getLocalManifest().getSearchPaths();
console.log("new path: " + JSON.stringify(a));
for (var o = 0; o < a.length; o++) -1 == s.indexOf(a[o]) && Array.prototype.unshift.apply(s, [ a[o] ]);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(s));
jsb.fileUtils.setSearchPaths(s);
cc.audioEngine.stopAll();
cc.game.restart();
}
},
loadCustomManifest: function() {
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = new jsb.Manifest((e = this.stringHost, JSON.stringify({
packageUrl: e + "/",
remoteManifestUrl: e + "/project.manifest",
remoteVersionUrl: e + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
})), this._storagePath);
this._am.loadLocalManifest(t, this._storagePath);
this.panel.info.string = "Using custom manifest";
}
var e;
},
retry: function() {
if (!this._updating && this._canRetry) {
this.panel.retryBtn.active = !1;
this._canRetry = !1;
this.panel.info.string = "Retry failed Assets...";
this._am.downloadFailedAssets();
}
},
checkUpdate: function() {
if (this._updating) {
this.panel.info.string = "Checking or updating ...";
return !1;
}
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (t = cc.loader.md5Pipe.transformURL(t));
this._am.loadLocalManifest(t);
}
if (!this._am.getLocalManifest() || !this._am.getLocalManifest().isLoaded()) {
this.panel.info.string = "Failed to load local manifest ...";
return !1;
}
this._am.setEventCallback(this.checkCb.bind(this));
this._am.checkUpdate();
this._updating = !0;
return !0;
},
hotUpdate: function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (t = cc.loader.md5Pipe.transformURL(t));
this._am.loadLocalManifest(t);
}
this._failCount = 0;
this._am.update();
this.panel.updateBtn.active = !1;
this._updating = !0;
}
},
show: function() {
!1 === this.updateUI.active && (this.updateUI.active = !0);
},
onLoad: function() {
if (cc.sys.isNative) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-assets";
cc.log("Storage path for remote asset : " + this._storagePath);
this.versionCompareHandle = function(t, e) {
cc.log("JS Custom Version Compare: version A is " + t + ", version B is " + e);
for (var n = t.split("."), i = e.split("."), s = 0; s < n.length; ++s) {
var a = parseInt(n[s]), o = parseInt(i[s] || 0);
if (a !== o) return a - o;
}
return i.length > n.length ? -1 : 0;
};
this._am = new jsb.AssetsManager("", this._storagePath, this.versionCompareHandle);
var t = this.panel;
this._am.setVerifyCallback(function(e, n) {
var i = n.compressed;
n.md5, n.path, n.size;
if (i) {
t.info.string = "Đang cập nhật phiên bản mới nhất...";
return !0;
}
t.info.string = "Đang cập nhật phiên bản mới nhất...";
return !0;
});
this.panel.info.string = "Hot update is ready, please check or directly update.";
if (cc.sys.os === cc.sys.OS_ANDROID) {
this._am.setMaxConcurrentTask(4);
this.panel.info.string = "Max concurrent tasks count have been limited to 4";
}
this.panel.fileProgress.progress = 0;
this.panel.byteProgress.progress = 0;
}
},
onDestroy: function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
}
});
cc._RF.pop();
}, {
"../UI/UpdatePanel": "UpdatePanel"
} ],
InGameUI: [ function(t, e) {
"use strict";
cc._RF.push(e, "f192efroeFEyaxtfh8TVXYz", "InGameUI");
var n = t("Game");
cc.Class({
extends: cc.Component,
properties: {
panelChat: {
default: null,
type: cc.Node
},
panelSocial: {
default: null,
type: cc.Node
},
betStateUI: {
default: null,
type: cc.Node
},
gameStateUI: {
default: null,
type: cc.Node
},
resultTxt: {
default: null,
type: cc.Label
},
betCounter: {
default: null,
type: cc.Node
},
btnStart: {
default: null,
type: cc.Node
},
labelTotalChips: {
default: null,
type: cc.Label
}
},
init: function(t) {
this.panelChat.active = !1;
this.panelSocial.active = !1;
this.resultTxt.enabled = !1;
this.betStateUI.active = !0;
this.gameStateUI.active = !1;
this.btnStart.active = !1;
this.betDuration = t;
this.progressTimer = this.initCountdown();
},
initCountdown: function() {
var t = n.instance.assetMng.texBetCountdown.getTexture();
this.sgCountdown = new _ccsg.Sprite(t);
this.sgCountdown.setColor(cc.Color.BLACK);
var e = new cc.ProgressTimer(this.sgCountdown);
e.setName("progressTimer");
e.setMidpoint(cc.v2(.5, .5));
e.setType(cc.ProgressTimer.Type.RADIAL);
e.reverseDir = !0;
this.betCounter._sgNode.addChild(e);
e.setPosition(cc.v2(0, -this.betCounter.height / 2));
e.setPercentage(0);
return e;
},
startCountdown: function() {
if (this.progressTimer) {
var t = cc.progressFromTo(this.betDuration, 0, 100);
this.progressTimer.runAction(t);
}
},
resetCountdown: function() {
if (this.progressTimer) {
this.progressTimer.stopAllActions();
this.progressTimer.setPercentage(100);
}
},
showBetState: function() {
this.betStateUI.active = !0;
this.gameStateUI.active = !1;
this.btnStart.active = !1;
},
showGameState: function() {
this.betStateUI.active = !1;
this.gameStateUI.active = !0;
this.btnStart.active = !1;
},
showResultState: function() {
this.betStateUI.active = !1;
this.gameStateUI.active = !1;
this.btnStart.active = !0;
},
toggleChat: function() {
this.panelChat.active = !this.panelChat.active;
},
toggleSocial: function() {
this.panelSocial.active = !this.panelSocial.active;
},
update: function() {}
});
cc._RF.pop();
}, {
Game: "Game"
} ],
Mask: [ function(t, e) {
"use strict";
cc._RF.push(e, "3c16c3le6hCsrtnanqK8N2W", "Mask");
cc.Class({
extends: cc.Component,
properties: {},
onLoad: function() {
this.node.on("touchstart", function(t) {
t.stopPropagation();
});
this.node.on("mousedown", function(t) {
t.stopPropagation();
});
this.node.on("mousemove", function(t) {
t.stopPropagation();
});
this.node.on("mouseup", function(t) {
t.stopPropagation();
});
}
});
cc._RF.pop();
}, {} ],
Menu: [ function(t, e) {
"use strict";
cc._RF.push(e, "20f60m+3RlGO7x2/ARzZ6Qc", "Menu");
cc.Class({
extends: cc.Component,
properties: {
audioMng: {
default: null,
type: cc.Node
}
},
onLoad: function() {
this.audioMng = this.audioMng.getComponent("AudioMng");
this.audioMng.playMusic();
},
playGame: function() {
cc.director.loadScene("table");
},
update: function() {}
});
cc._RF.pop();
}, {} ],
PlayerData: [ function(t, e) {
"use strict";
cc._RF.push(e, "4f9c5eXxqhHAKLxZeRmgHDB", "PlayerData");
e.exports = {
players: [ {
name: "燃烧吧，蛋蛋儿军",
gold: 3e3,
photoIdx: 0
}, {
name: "地方政府",
gold: 2e3,
photoIdx: 1
}, {
name: "手机超人",
gold: 1500,
photoIdx: 2
}, {
name: "天灵灵，地灵灵",
gold: 500,
photoIdx: 3
}, {
name: "哟哟，切克闹",
gold: 9e3,
photoIdx: 4
}, {
name: "学姐不要死",
gold: 5e3,
photoIdx: 5
}, {
name: "提百万",
gold: 1e4,
photoIdx: 6
} ]
};
cc._RF.pop();
}, {} ],
Player: [ function(t, e) {
"use strict";
cc._RF.push(e, "226a2AvzRpHL7SJGTMy5PDX", "Player");
var n = t("Actor");
cc.Class({
extends: n,
init: function() {
this._super();
this.labelStake = this.renderer.labelStakeOnTable;
this.stakeNum = 0;
},
reset: function() {
this._super();
this.resetStake();
},
addCard: function(t) {
this._super(t);
},
addStake: function(t) {
this.stakeNum += t;
this.updateStake(this.stakeNum);
},
resetStake: function() {
this.stakeNum = 0;
this.updateStake(this.stakeNum);
},
updateStake: function(t) {
this.labelStake.string = t;
}
});
cc._RF.pop();
}, {
Actor: "Actor"
} ],
RankItem: [ function(t, e) {
"use strict";
cc._RF.push(e, "1657ewfijBOXLq5zGqr6PvE", "RankItem");
cc.Class({
extends: cc.Component,
properties: {
spRankBG: {
default: null,
type: cc.Sprite
},
labelRank: {
default: null,
type: cc.Label
},
labelPlayerName: {
default: null,
type: cc.Label
},
labelGold: {
default: null,
type: cc.Label
},
spPlayerPhoto: {
default: null,
type: cc.Sprite
},
texRankBG: {
default: [],
type: cc.SpriteFrame
},
texPlayerPhoto: {
default: [],
type: cc.SpriteFrame
}
},
init: function(t, e) {
if (t < 3) {
this.labelRank.node.active = !1;
this.spRankBG.spriteFrame = this.texRankBG[t];
} else {
this.labelRank.node.active = !0;
this.labelRank.string = (t + 1).toString();
}
this.labelPlayerName.string = e.name;
this.labelGold.string = e.gold.toString();
this.spPlayerPhoto.spriteFrame = this.texPlayerPhoto[e.photoIdx];
},
update: function() {}
});
cc._RF.pop();
}, {} ],
RankList: [ function(t, e) {
"use strict";
cc._RF.push(e, "fe3fcIxCFFLrKHg6s5+xRUU", "RankList");
var n = t("PlayerData").players;
cc.Class({
extends: cc.Component,
properties: {
scrollView: {
default: null,
type: cc.ScrollView
},
prefabRankItem: {
default: null,
type: cc.Prefab
},
rankCount: 0
},
onLoad: function() {
this.content = this.scrollView.content;
this.populateList();
},
populateList: function() {
for (var t = 0; t < this.rankCount; ++t) {
var e = n[t], i = cc.instantiate(this.prefabRankItem);
i.getComponent("RankItem").init(t, e);
this.content.addChild(i);
}
},
update: function() {}
});
cc._RF.pop();
}, {
PlayerData: "PlayerData"
} ],
SideSwitcher: [ function(t, e) {
"use strict";
cc._RF.push(e, "3aae7lZKyhPqqsLD3wMKl6X", "SideSwitcher");
cc.Class({
extends: cc.Component,
properties: {
retainSideNodes: {
default: [],
type: cc.Node
}
},
switchSide: function() {
this.node.scaleX = -this.node.scaleX;
for (var t = 0; t < this.retainSideNodes.length; ++t) {
var e = this.retainSideNodes[t];
e.scaleX = -e.scaleX;
}
}
});
cc._RF.pop();
}, {} ],
TossChip: [ function(t, e) {
"use strict";
cc._RF.push(e, "b4eb5Lo6U1IZ4eJWuxShCdH", "TossChip");
cc.Class({
extends: cc.Component,
properties: {
anim: {
default: null,
type: cc.Animation
}
},
play: function() {
this.anim.play("chip_toss");
}
});
cc._RF.pop();
}, {} ],
Types: [ function(t, e) {
"use strict";
cc._RF.push(e, "5b633QMQxpFmYetofEvK2UD", "Types");
var n = cc.Enum({
Spade: 1,
Heart: 2,
Club: 3,
Diamond: 4
}), i = "NAN,A,2,3,4,5,6,7,8,9,10,J,Q,K".split(",");
function s(t, e) {
Object.defineProperties(this, {
point: {
value: t,
writable: !1
},
suit: {
value: e,
writable: !1
},
id: {
value: 13 * (e - 1) + (t - 1),
writable: !1
},
pointName: {
get: function() {
return i[this.point];
}
},
suitName: {
get: function() {
return n[this.suit];
}
},
isBlackSuit: {
get: function() {
return this.suit === n.Spade || this.suit === n.Club;
}
},
isRedSuit: {
get: function() {
return this.suit === n.Heart || this.suit === n.Diamond;
}
}
});
}
s.prototype.toString = function() {
return this.suitName + " " + this.pointName;
};
var a = new Array(52);
s.fromId = function(t) {
return a[t];
};
(function() {
for (var t = 1; t <= 4; t++) for (var e = 1; e <= 13; e++) {
var n = new s(e, t);
a[n.id] = n;
}
})();
var o = cc.Enum({
Normal: -1,
Stand: -1,
Report: -1,
Bust: -1
}), r = cc.Enum({
Win: -1,
Lose: -1,
Tie: -1
}), c = cc.Enum({
Normal: -1,
BlackJack: -1,
FiveCard: -1
});
e.exports = {
Suit: n,
Card: s,
ActorPlayingState: o,
Hand: c,
Outcome: r
};
cc._RF.pop();
}, {} ],
UpdatePanel: [ function(t, e) {
"use strict";
cc._RF.push(e, "2db08jFZqNN+rw8vpeF4j70", "UpdatePanel");
e.exports = cc.Class({
extends: cc.Component,
properties: {
info: cc.Label,
fileProgress: cc.ProgressBar,
fileLabel: cc.Label,
byteProgress: cc.ProgressBar,
byteLabel: cc.Label,
close: cc.Node,
checkBtn: cc.Node,
retryBtn: cc.Node,
updateBtn: cc.Node
},
onLoad: function() {
this.close.on(cc.Node.EventType.TOUCH_END, function() {
this.node.parent.active = !1;
}, this);
}
});
cc._RF.pop();
}, {} ],
Utils: [ function(t, e) {
"use strict";
cc._RF.push(e, "73590esk6xP9ICqhfUZalMg", "Utils");
e.exports = {
isBust: function(t) {
for (var e = 0, n = 0; n < t.length; n++) {
var i = t[n];
e += Math.min(10, i.point);
}
return e > 21;
},
getMinMaxPoint: function(t) {
for (var e = !1, n = 0, i = 0; i < t.length; i++) {
var s = t[i];
1 === s.point && (e = !0);
n += Math.min(10, s.point);
}
var a = n;
e && n + 10 <= 21 && (a += 10);
return {
min: n,
max: a
};
},
isMobile: function() {
return cc.sys.isMobile;
}
};
cc._RF.pop();
}, {} ],
"game-fsm": [ function(t, e, n) {
"use strict";
cc._RF.push(e, "6510d1SmQRMMYH8FEIA7zXq", "game-fsm");
var i, s, a, o = t("state.com");
function r(t) {
return function(e) {
return e === t;
};
}
var c = !1;
n = {
init: function(t) {
o.console = console;
s = new o.StateMachine("root");
var e = new o.PseudoState("init-root", s, o.PseudoStateKind.Initial), n = new o.State("下注", s);
a = new o.State("已开局", s);
var c = new o.State("结算", s);
e.to(n);
n.to(a).when(r("deal"));
a.to(c).when(r("end"));
c.to(n).when(r("bet"));
n.entry(function() {
t.onBetState(!0);
});
n.exit(function() {
t.onBetState(!1);
});
c.entry(function() {
t.onEndState(!0);
});
c.exit(function() {
t.onEndState(!1);
});
var u = new o.PseudoState("init 已开局", a, o.PseudoStateKind.Initial), l = new o.State("发牌", a), h = new o.State("玩家决策", a), p = new o.State("庄家决策", a);
u.to(l);
l.to(h).when(r("dealed"));
h.to(p).when(r("player acted"));
l.entry(function() {
t.onEnterDealState();
});
h.entry(function() {
t.onPlayersTurnState(!0);
});
h.exit(function() {
t.onPlayersTurnState(!1);
});
p.entry(function() {
t.onEnterDealersTurnState();
});
i = new o.StateMachineInstance("fsm");
o.initialise(s, i);
},
toDeal: function() {
this._evaluate("deal");
},
toBet: function() {
this._evaluate("bet");
},
onDealed: function() {
this._evaluate("dealed");
},
onPlayerActed: function() {
this._evaluate("player acted");
},
onDealerActed: function() {
this._evaluate("end");
},
_evaluate: function(t) {
if (c) setTimeout(function() {
o.evaluate(s, i, t);
}, 1); else {
c = !0;
o.evaluate(s, i, t);
c = !1;
}
},
_getInstance: function() {
return i;
},
_getModel: function() {
return s;
}
};
e.exports = n;
cc._RF.pop();
}, {
"state.com": "state.com"
} ],
"state.com": [ function(t, e) {
"use strict";
cc._RF.push(e, "71d9293mx9CFryhJvRw85ZS", "state.com");
(function(t) {
var e = function() {
function t(t) {
this.actions = [];
t && this.push(t);
}
t.prototype.push = function(e) {
Array.prototype.push.apply(this.actions, e instanceof t ? e.actions : arguments);
return this;
};
t.prototype.hasActions = function() {
return 0 !== this.actions.length;
};
t.prototype.invoke = function(t, e, n) {
void 0 === n && (n = !1);
this.actions.forEach(function(i) {
return i(t, e, n);
});
};
return t;
}();
t.Behavior = e;
})(n || (n = {}));
(function(t) {
(function(t) {
t[t.Initial = 0] = "Initial";
t[t.ShallowHistory = 1] = "ShallowHistory";
t[t.DeepHistory = 2] = "DeepHistory";
t[t.Choice = 3] = "Choice";
t[t.Junction = 4] = "Junction";
t[t.Terminate = 5] = "Terminate";
})(t.PseudoStateKind || (t.PseudoStateKind = {}));
t.PseudoStateKind;
})(n || (n = {}));
(function(t) {
(function(t) {
t[t.Internal = 0] = "Internal";
t[t.Local = 1] = "Local";
t[t.External = 2] = "External";
})(t.TransitionKind || (t.TransitionKind = {}));
t.TransitionKind;
})(n || (n = {}));
(function(t) {
var e = function() {
function t(e, n) {
this.name = e;
this.qualifiedName = n ? n.qualifiedName + t.namespaceSeparator + e : e;
}
t.prototype.toString = function() {
return this.qualifiedName;
};
t.namespaceSeparator = ".";
return t;
}();
t.Element = e;
})(n || (n = {}));
var n, i = function(t, e) {
for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
function i() {
this.constructor = t;
}
i.prototype = e.prototype;
t.prototype = new i();
};
(function(t) {
var e = function(t) {
i(e, t);
function e(e, n) {
t.call(this, e, n);
this.vertices = [];
this.state = n;
this.state.regions.push(this);
this.state.getRoot().clean = !1;
}
e.prototype.getRoot = function() {
return this.state.getRoot();
};
e.prototype.accept = function(t, e, n, i) {
return t.visitRegion(this, e, n, i);
};
e.defaultName = "default";
return e;
}(t.Element);
t.Region = e;
})(n || (n = {}));
(function(t) {
var e = function(e) {
i(n, e);
function n(n, i) {
e.call(this, n, i = i instanceof t.State ? i.defaultRegion() : i);
this.outgoing = [];
this.region = i;
if (this.region) {
this.region.vertices.push(this);
this.region.getRoot().clean = !1;
}
}
n.prototype.getRoot = function() {
return this.region.getRoot();
};
n.prototype.to = function(e, n) {
void 0 === n && (n = t.TransitionKind.External);
return new t.Transition(this, e, n);
};
n.prototype.accept = function() {};
return n;
}(t.Element);
t.Vertex = e;
})(n || (n = {}));
(function(t) {
var e = function(e) {
i(n, e);
function n(n, i, s) {
void 0 === s && (s = t.PseudoStateKind.Initial);
e.call(this, n, i);
this.kind = s;
}
n.prototype.isHistory = function() {
return this.kind === t.PseudoStateKind.DeepHistory || this.kind === t.PseudoStateKind.ShallowHistory;
};
n.prototype.isInitial = function() {
return this.kind === t.PseudoStateKind.Initial || this.isHistory();
};
n.prototype.accept = function(t, e, n, i) {
return t.visitPseudoState(this, e, n, i);
};
return n;
}(t.Vertex);
t.PseudoState = e;
})(n || (n = {}));
(function(t) {
var e = function(e) {
i(n, e);
function n(n, i) {
e.call(this, n, i);
this.exitBehavior = new t.Behavior();
this.entryBehavior = new t.Behavior();
this.regions = [];
}
n.prototype.defaultRegion = function() {
return this.regions.reduce(function(e, n) {
return n.name === t.Region.defaultName ? n : e;
}, void 0) || new t.Region(t.Region.defaultName, this);
};
n.prototype.isFinal = function() {
return 0 === this.outgoing.length;
};
n.prototype.isSimple = function() {
return 0 === this.regions.length;
};
n.prototype.isComposite = function() {
return this.regions.length > 0;
};
n.prototype.isOrthogonal = function() {
return this.regions.length > 1;
};
n.prototype.exit = function(t) {
this.exitBehavior.push(t);
this.getRoot().clean = !1;
return this;
};
n.prototype.entry = function(t) {
this.entryBehavior.push(t);
this.getRoot().clean = !1;
return this;
};
n.prototype.accept = function(t, e, n, i) {
return t.visitState(this, e, n, i);
};
return n;
}(t.Vertex);
t.State = e;
})(n || (n = {}));
(function(t) {
var e = function(t) {
i(e, t);
function e(e, n) {
t.call(this, e, n);
}
e.prototype.accept = function(t, e, n, i) {
return t.visitFinalState(this, e, n, i);
};
return e;
}(t.State);
t.FinalState = e;
})(n || (n = {}));
(function(t) {
var e = function(t) {
i(e, t);
function e(e) {
t.call(this, e, void 0);
this.clean = !1;
}
e.prototype.getRoot = function() {
return this.region ? this.region.getRoot() : this;
};
e.prototype.accept = function(t, e, n, i) {
return t.visitStateMachine(this, e, n, i);
};
return e;
}(t.State);
t.StateMachine = e;
})(n || (n = {}));
(function(t) {
var e = function() {
function e(n, i, s) {
var a = this;
void 0 === s && (s = t.TransitionKind.External);
this.transitionBehavior = new t.Behavior();
this.onTraverse = new t.Behavior();
this.source = n;
this.target = i;
this.kind = i ? s : t.TransitionKind.Internal;
this.guard = n instanceof t.PseudoState ? e.TrueGuard : function(t) {
return t === a.source;
};
this.source.outgoing.push(this);
this.source.getRoot().clean = !1;
}
e.prototype.else = function() {
this.guard = e.FalseGuard;
return this;
};
e.prototype.when = function(t) {
this.guard = t;
return this;
};
e.prototype.effect = function(t) {
this.transitionBehavior.push(t);
this.source.getRoot().clean = !1;
return this;
};
e.prototype.accept = function(t, e, n, i) {
return t.visitTransition(this, e, n, i);
};
e.prototype.toString = function() {
return "[" + (this.target ? this.source + " -> " + this.target : this.source) + "]";
};
e.TrueGuard = function() {
return !0;
};
e.FalseGuard = function() {
return !1;
};
return e;
}();
t.Transition = e;
})(n || (n = {}));
(function(t) {
var e = function() {
function t() {}
t.prototype.visitElement = function() {};
t.prototype.visitRegion = function(t, e, n, i) {
var s = this, a = this.visitElement(t, e, n, i);
t.vertices.forEach(function(t) {
t.accept(s, e, n, i);
});
return a;
};
t.prototype.visitVertex = function(t, e, n, i) {
var s = this, a = this.visitElement(t, e, n, i);
t.outgoing.forEach(function(t) {
t.accept(s, e, n, i);
});
return a;
};
t.prototype.visitPseudoState = function(t, e, n, i) {
return this.visitVertex(t, e, n, i);
};
t.prototype.visitState = function(t, e, n, i) {
var s = this, a = this.visitVertex(t, e, n, i);
t.regions.forEach(function(t) {
t.accept(s, e, n, i);
});
return a;
};
t.prototype.visitFinalState = function(t, e, n, i) {
return this.visitState(t, e, n, i);
};
t.prototype.visitStateMachine = function(t, e, n, i) {
return this.visitState(t, e, n, i);
};
t.prototype.visitTransition = function() {};
return t;
}();
t.Visitor = e;
})(n || (n = {}));
(function(t) {
var e = function() {
function t(t) {
void 0 === t && (t = "unnamed");
this.last = {};
this.isTerminated = !1;
this.name = t;
}
t.prototype.setCurrent = function(t, e) {
this.last[t.qualifiedName] = e;
};
t.prototype.getCurrent = function(t) {
return this.last[t.qualifiedName];
};
t.prototype.toString = function() {
return this.name;
};
return t;
}();
t.StateMachineInstance = e;
})(n || (n = {}));
(function(t) {
t.setRandom = function(t) {
e = t;
};
t.getRandom = function() {
return e;
};
var e = function(t) {
return Math.floor(Math.random() * t);
};
})(n || (n = {}));
(function(t) {
t.isActive = function e(n, i) {
return n instanceof t.Region ? e(n.state, i) : n instanceof t.State ? !n.region || e(n.region, i) && i.getCurrent(n.region) === n : void 0;
};
})(n || (n = {}));
(function(t) {
t.isComplete = function e(n, i) {
return n instanceof t.Region ? i.getCurrent(n).isFinal() : !(n instanceof t.State) || n.regions.every(function(t) {
return e(t, i);
});
};
})(n || (n = {}));
(function(t) {
function e(n, i, s) {
void 0 === s && (s = !0);
if (i) {
s && !1 === n.clean && e(n);
t.console.log("initialise " + i);
n.onInitialise.invoke(void 0, i);
} else {
t.console.log("initialise " + n.name);
n.accept(new d(), !1);
n.clean = !0;
}
}
t.initialise = e;
t.evaluate = function(i, s, a, o) {
void 0 === o && (o = !0);
t.console.log(s + " evaluate " + a);
o && !1 === i.clean && e(i);
return !s.isTerminated && n(i, s, a);
};
function n(e, i, a) {
var o = !1;
e.regions.every(function(s) {
if (n(i.getCurrent(s), i, a)) {
o = !0;
return t.isActive(e, i);
}
return !0;
});
if (o) a !== e && t.isComplete(e, i) && n(e, i, e); else {
var r = e.outgoing.filter(function(t) {
return t.guard(a, i);
});
1 === r.length ? o = s(r[0], i, a) : r.length > 1 && t.console.error(e + ": multiple outbound transitions evaluated true for message " + a);
}
return o;
}
function s(e, i, o) {
for (var r = new t.Behavior(e.onTraverse), c = e.target; c && c instanceof t.PseudoState && c.kind === t.PseudoStateKind.Junction; ) {
c = (e = a(c, i, o)).target;
r.push(e.onTraverse);
}
r.invoke(o, i);
c && c instanceof t.PseudoState && c.kind === t.PseudoStateKind.Choice ? s(a(c, i, o), i, o) : c && c instanceof t.State && t.isComplete(c, i) && n(c, i, c);
return !0;
}
function a(e, n, i) {
var s = e.outgoing.filter(function(t) {
return t.guard(i, n);
});
if (e.kind === t.PseudoStateKind.Choice) return 0 !== s.length ? s[t.getRandom()(s.length)] : o(e);
if (!(s.length > 1)) return s[0] || o(e);
t.console.error("Multiple outbound transition guards returned true at " + this + " for " + i);
}
function o(e) {
return e.outgoing.filter(function(e) {
return e.guard === t.Transition.FalseGuard;
})[0];
}
function r(e) {
return e[0] || (e[0] = new t.Behavior());
}
function c(e) {
return e[1] || (e[1] = new t.Behavior());
}
function u(e) {
return e[2] || (e[2] = new t.Behavior());
}
function l(e) {
return new t.Behavior(c(e)).push(u(e));
}
function h(t) {
return (t.region ? h(t.region.state) : []).concat(t);
}
var p = function(e) {
i(n, e);
function n() {
e.apply(this, arguments);
}
n.prototype.visitTransition = function(e, n) {
e.kind === t.TransitionKind.Internal ? e.onTraverse.push(e.transitionBehavior) : e.kind === t.TransitionKind.Local ? this.visitLocalTransition(e, n) : this.visitExternalTransition(e, n);
};
n.prototype.visitLocalTransition = function(e, n) {
var i = this;
e.onTraverse.push(function(s, a) {
for (var o = h(e.target), c = 0; t.isActive(o[c], a); ) ++c;
r(n(a.getCurrent(o[c].region))).invoke(s, a);
e.transitionBehavior.invoke(s, a);
for (;c < o.length; ) i.cascadeElementEntry(e, n, o[c++], o[c], function(t) {
t.invoke(s, a);
});
u(n(e.target)).invoke(s, a);
});
};
n.prototype.visitExternalTransition = function(t, e) {
for (var n = h(t.source), i = h(t.target), s = Math.min(n.length, i.length) - 1; n[s - 1] !== i[s - 1]; ) --s;
t.onTraverse.push(r(e(n[s])));
t.onTraverse.push(t.transitionBehavior);
for (;s < i.length; ) this.cascadeElementEntry(t, e, i[s++], i[s], function(e) {
return t.onTraverse.push(e);
});
t.onTraverse.push(u(e(t.target)));
};
n.prototype.cascadeElementEntry = function(e, n, i, s, a) {
a(c(n(i)));
s && i instanceof t.State && i.regions.forEach(function(t) {
a(c(n(t)));
t !== s.region && a(u(n(t)));
});
};
return n;
}(t.Visitor), d = function(e) {
i(n, e);
function n() {
e.apply(this, arguments);
this.behaviours = {};
}
n.prototype.behaviour = function(t) {
return this.behaviours[t.qualifiedName] || (this.behaviours[t.qualifiedName] = []);
};
n.prototype.visitElement = function(e) {
if (t.console !== f) {
r(this.behaviour(e)).push(function(n, i) {
return t.console.log(i + " leave " + e);
});
c(this.behaviour(e)).push(function(n, i) {
return t.console.log(i + " enter " + e);
});
}
};
n.prototype.visitRegion = function(e, n) {
var i = this, s = e.vertices.reduce(function(e, n) {
return n instanceof t.PseudoState && n.isInitial() ? n : e;
}, void 0);
e.vertices.forEach(function(e) {
e.accept(i, n || s && s.kind === t.PseudoStateKind.DeepHistory);
});
r(this.behaviour(e)).push(function(t, n) {
return r(i.behaviour(n.getCurrent(e))).invoke(t, n);
});
n || !s || s.isHistory() ? u(this.behaviour(e)).push(function(n, a, o) {
l(i.behaviour((o || s.isHistory()) && a.getCurrent(e) || s)).invoke(n, a, o || s.kind === t.PseudoStateKind.DeepHistory);
}) : u(this.behaviour(e)).push(l(this.behaviour(s)));
this.visitElement(e, n);
};
n.prototype.visitPseudoState = function(n, i) {
e.prototype.visitPseudoState.call(this, n, i);
n.isInitial() ? u(this.behaviour(n)).push(function(t, e) {
return s(n.outgoing[0], e);
}) : n.kind === t.PseudoStateKind.Terminate && c(this.behaviour(n)).push(function(t, e) {
return e.isTerminated = !0;
});
};
n.prototype.visitState = function(t, e) {
var n = this;
t.regions.forEach(function(i) {
i.accept(n, e);
r(n.behaviour(t)).push(r(n.behaviour(i)));
u(n.behaviour(t)).push(l(n.behaviour(i)));
});
this.visitVertex(t, e);
r(this.behaviour(t)).push(t.exitBehavior);
c(this.behaviour(t)).push(t.entryBehavior);
c(this.behaviour(t)).push(function(e, n) {
t.region && n.setCurrent(t.region, t);
});
};
n.prototype.visitStateMachine = function(t, n) {
var i = this;
e.prototype.visitStateMachine.call(this, t, n);
t.accept(new p(), function(t) {
return i.behaviour(t);
});
t.onInitialise = l(this.behaviour(t));
};
return n;
}(t.Visitor), f = {
log: function() {
for (var t = [], e = 1; e < arguments.length; e++) t[e - 1] = arguments[e];
},
warn: function() {
for (var t = [], e = 1; e < arguments.length; e++) t[e - 1] = arguments[e];
},
error: function(t) {
for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
throw t;
}
};
t.console = f;
})(n || (n = {}));
(function(t) {
t.validate = function(t) {
t.accept(new n());
};
function e(t) {
return (t.region ? e(t.region.state) : []).concat(t);
}
var n = function(n) {
i(s, n);
function s() {
n.apply(this, arguments);
}
s.prototype.visitPseudoState = function(e) {
n.prototype.visitPseudoState.call(this, e);
if (e.kind === t.PseudoStateKind.Choice || e.kind === t.PseudoStateKind.Junction) {
0 === e.outgoing.length && t.console.error(e + ": " + e.kind + " pseudo states must have at least one outgoing transition.");
e.outgoing.filter(function(e) {
return e.guard === t.Transition.FalseGuard;
}).length > 1 && t.console.error(e + ": " + e.kind + " pseudo states cannot have more than one Else transitions.");
} else {
0 !== e.outgoing.filter(function(e) {
return e.guard === t.Transition.FalseGuard;
}).length && t.console.error(e + ": " + e.kind + " pseudo states cannot have Else transitions.");
e.isInitial() && (1 !== e.outgoing.length ? t.console.error(e + ": initial pseudo states must have one outgoing transition.") : e.outgoing[0].guard !== t.Transition.TrueGuard && t.console.error(e + ": initial pseudo states cannot have a guard condition."));
}
};
s.prototype.visitRegion = function(e) {
n.prototype.visitRegion.call(this, e);
var i;
e.vertices.forEach(function(n) {
if (n instanceof t.PseudoState && n.isInitial()) {
i && t.console.error(e + ": regions may have at most one initial pseudo state.");
i = n;
}
});
};
s.prototype.visitState = function(e) {
n.prototype.visitState.call(this, e);
e.regions.filter(function(e) {
return e.name === t.Region.defaultName;
}).length > 1 && t.console.error(e + ": a state cannot have more than one region named " + t.Region.defaultName);
};
s.prototype.visitFinalState = function(e) {
n.prototype.visitFinalState.call(this, e);
0 !== e.outgoing.length && t.console.error(e + ": final states must not have outgoing transitions.");
0 !== e.regions.length && t.console.error(e + ": final states must not have child regions.");
e.entryBehavior.hasActions() && t.console.warn(e + ": final states may not have entry behavior.");
e.exitBehavior.hasActions() && t.console.warn(e + ": final states may not have exit behavior.");
};
s.prototype.visitTransition = function(i) {
n.prototype.visitTransition.call(this, i);
i.kind === t.TransitionKind.Local && -1 === e(i.target).indexOf(i.source) && t.console.error(i + ": local transition target vertices must be a child of the source composite sate.");
};
return s;
}(t.Visitor);
})(n || (n = {}));
e.exports = n;
cc._RF.pop();
}, {} ],
use_reversed_rotateTo: [ function(t, e) {
"use strict";
cc._RF.push(e, "42911BMc1pNmqCrA7BVrFuS", "use_reversed_rotateTo");
cc.RotateTo._reverse = !0;
cc._RF.pop();
}, {} ],
"use_v2.0.x_cc.Toggle_event": [ function(t, e) {
"use strict";
cc._RF.push(e, "6c0afgPAiZDbrKKijhNiSOB", "use_v2.0.x_cc.Toggle_event");
cc.Toggle && (cc.Toggle._triggerEventInScript_check = !0);
cc._RF.pop();
}, {} ]
}, {}, [ "use_reversed_rotateTo", "use_v2.0.x_cc.Toggle_event", "Actor", "ActorRenderer", "AssetMng", "AudioMng", "Bet", "Card", "CounterTest", "Dealer", "FXPlayer", "Game", "Menu", "Player", "SideSwitcher", "TossChip", "ButtonScaler", "InGameUI", "RankItem", "RankList", "UpdatePanel", "state.com", "Decks", "HotUpdate", "Mask", "PlayerData", "Types", "Utils", "game-fsm" ]);